document.getElementById('scrollGalleryBtn').addEventListener('click', function() {
    document.body.classList.add('fade-out-main');
    setTimeout(function() {
      document.getElementById('gallery').scrollIntoView({ behavior: 'smooth' });
    }, 400);
  });
  
  window.addEventListener('scroll', function() {
    var gallery = document.getElementById('gallery');
    var rect = gallery.getBoundingClientRect();
    if(rect.top < window.innerHeight * 0.8) {
      gallery.classList.add('gallery-visible');
    }
  });